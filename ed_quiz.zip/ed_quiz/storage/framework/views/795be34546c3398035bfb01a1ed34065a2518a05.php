<!DOCTYPE html>
<html lang="en">
<head>
  <title>Verify Email</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <script type="text/javascript" src="<?php echo e(asset('js/custom.js')); ?>"></script>
</head>
<body>

<div class="container">
  <h2>Verify Email</h2>
 <div class="loading-image" style="position: absolute;
    top: 16%;
    left: 40%;">
<img src="<?php echo e(asset('kloader.gif')); ?>" class='loader'  style=" width:'69%'">
</div>
    <div class="form-group">
      <label for="email">Email:</label>
      <input type="email" class="form-control" id="email" placeholder="Enter email" name="email">
    </div>
      <?php echo e(csrf_field()); ?>

   
    <button id='submitEmail' type="submit" class="btn btn-default">Submit</button>

</div>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\quiz_ed\ed_quiz\resources\views/welcome.blade.php ENDPATH**/ ?>