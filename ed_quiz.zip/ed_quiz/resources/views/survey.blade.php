

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <script type="text/javascript" src="{{ asset('js/custom.js') }}"></script>
</head>
<body>
<div class="container">
<h1 style='text-align:center;text-decoration: underline;'>Student Survey</h1>
   <br>    <br> 
<div class="loading-image" style="position: absolute;
    top: 16%;
    left: 40%;">
<img src="{{ asset('kloader.gif') }}" class='loader'  style=" width:69%">
</div>
@foreach ($questions as $question => $questionkey)
<form id='nextdiv<?php echo $question ?>'  class='nextdiv'>
 <div   >
  <?php $count=1;  ?>
  <input type="hidden" id="step"  name="step" value="<?php echo $question;  ?>">
  @foreach ($questionkey as $questioninner => $key)
    <h4> <strong> <?php echo $key['id'] ?>. ) <?php echo $key['name'];  ?> </strong></h4> 
    <input type="hidden" id="question_id"  name="main[<?php echo $key['id'] ?>][question]<?php echo $key['id'] ?>" value=" <?php echo $key['id'];  ?>">
      @foreach ($key['options'] as $questionoptions => $value)
        <input type="radio"  required name="main[<?php echo $key['id'] ?>][survey]" value="<?php echo $value['id'] ?>">
            <span> <?php echo $value['options'] ?></span><br>
      @endforeach
  @endforeach
   <br> 
   <div  style="text-align: center;">
    <input type="submit" class='nextbutton' value="Next Question">
     <input type="submit" style="margin: 0 auto" id="nextbuttonsurvey<?php echo $question;  ?>" value="End Survey">
   </div>
  </div>

</form>
@endforeach 
<br>  
{{ csrf_field() }}
<br> 
  <div id="suarveyThankyou" style="text-align: center">
  <strong>Thank  you for completing our survey</strong> 
  </div>
</div>
</body>
</html>
