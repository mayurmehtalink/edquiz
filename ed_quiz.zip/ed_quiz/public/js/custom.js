jQuery(document).ready(function($){
	$('#nextdiv1').css('display','none');
	$('#nextdiv2').css('display','none');
	
	$('.loading-image').hide();
	$('#suarveyThankyou').css('display','none');
	$('#nextbuttonsurvey0').css('display','none');
	$('#nextbuttonsurvey1').css('display','none');
	$('#nextbuttonsurvey2').css('display','none');
  	$("#submitEmail").click(function(e){
	      e.preventDefault();
	   $('.loading-image').show();
	     var email = $("#email").val();
	     if(!email){
	     	alert('Email Required');
	     }
	      var token =$("input[name=_token]").val();
	      console.log(token);
	    $.ajax({type: "POST",
	            url: "/verifyemail",
	            data: { email: email },
	             headers: {
	                    'X-CSRF-Token': token 
	               },
	            success:function(result){
	            	console.log(result);
	  				if(result.status==0){
						window.location.href = "survey";
				   }else{
				   	alert(result.message);
				   }
	   	 	},  complete: function(){
        $('.loading-image').hide();
      }});
  		});

	  $(".nextdiv").submit(function(event){
		event.preventDefault(); //prevent default action 
		var post_url = 'survey_submit'; //get form action url
		request_method='POST';
		  $('.loading-image').show();
		var token =$("input[name=_token]").val();
	//	//var request_method = $(this).attr("method"); //get form GET/POST method
		var form_data = $(this).serialize(); //Encode form elements for submission
		console.log(form_data);
		$.ajax({
			url : post_url,
			type: request_method,
			data : form_data ,
			 headers: {
	                    'X-CSRF-Token': token 
	               },
		}).done(function(response){ //
 			 $('.loading-image').hide();
			if(response.status == 1 && response.formstep == 0){
				$('#nextdiv1').css('display','block');
				$('#nextdiv0').css('display','none');	
				//$('#nextbuttonsurvey').css('display','none');;
			}
			if(response.status == 1 && response.formstep == 1){
				$('#nextdiv2').css('display','block');
				$('#nextdiv1').css('display','none');	
				$('.nextbutton').css('display','none');	
				$('#nextbuttonsurvey2').css('display','block');
			}
			if(response.status == 1 && response.formstep == 2){
				$('#suarveyThankyou').css('display','block');
				$('#nextdiv2').css('display','none');
				//$('#nextbuttonsurvey2').css('display','block');;		

			}
			//$("#server-results").html(response);

		});
	});
});