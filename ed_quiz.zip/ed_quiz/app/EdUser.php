<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EdUser extends Model
{

	    protected $table='ed_users';
    //
}
