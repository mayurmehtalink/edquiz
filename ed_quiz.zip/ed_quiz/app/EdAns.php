<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EdAns extends Model
{
    //
       protected $table = 'ed_answers';
       public $timestamps = false;
}
