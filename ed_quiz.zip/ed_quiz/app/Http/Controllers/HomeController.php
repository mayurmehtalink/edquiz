<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\EdUser;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Session;

class HomeController extends Controller
{
   
 	function index(){
		return view('welcome');
    }
    function verifyEmail(Request $request){

    	$email = $_POST['email'];
		$validator = Validator::make(
		    array(
		        'email' => $email
		    ),
		    array(
		      'email' => 'required|email|unique:ed_users'
		    )
		);
		if ($validator->fails())
		{
			$user_id= EdUser::where('email','=',$email)->get()->toArray();
			Session::forget('forget');
			Session::put('user_id', $user_id[0]['id']);
		   
		   	return  response()->json([ 'message' => 'Email exist', 'status' => 0 ]);
		 
		}
		else {
			return    response()->json([ 'message' => 'Email Not exist', 'status' => 1 ]);
		}
	}
}
