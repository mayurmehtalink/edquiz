<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\EdQuestion;
use App\EdOption;
use App\EdAns;
use Illuminate\Support\Facades\Session;

class QuizController extends Controller
{
    
    function index(){
    	$questions = EdQuestion::with('options')->get()->toArray();
    	$questions=array_chunk($questions, 2);
		return view('survey')->with('questions', $questions);
    }
    function survey_submit(){
     	$user_id = Session::get('user_id');
  
		foreach ($_POST['main'] as $key) {
			$task = new EdAns;
		    $task->question_id = $key['question'];
		    $task->user_id =$user_id;
		    $task->option_choice = $key['survey'];
		    $task->save();
		}
		
		return  response()->json([ 'message' => 'Ans Saved', 'status' => 1 , 'formstep'=>$_POST['step']  ]);

 
    }
}
