<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EdQuestion extends Model
{
    //
    protected $table = 'ed_questions';
       public function options()
    {
        return $this->hasMany('App\EdOption','questions_id','id');
    }
}
