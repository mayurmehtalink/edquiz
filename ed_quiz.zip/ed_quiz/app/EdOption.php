<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EdOption extends Model
{
    //

    protected $table ='ed_options';
}
