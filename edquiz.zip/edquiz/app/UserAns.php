<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserAns extends Model
{

	protected $table= 'ed_user_ans';
    //
}
