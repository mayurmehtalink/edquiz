<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Questionoption extends Model
{
    //
     protected $table = 'ed_question_option';

  
}
