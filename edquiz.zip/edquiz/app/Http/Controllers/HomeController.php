<?php

namespace App\Http\Controllers;

use App\Question;
use App\UserAns;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\User;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $user = Auth::user();
        //dd($user);
        if($user['page_ans'] == 0){
            $question = Question::with('options')->where('page_name','=','survey_one')->get();
             return view('questionpageone')->with('question', $question); ;
         }else{
            $question = UserAns::where('user_id','=', $user->id)->get();
             return view('home')->with('question', $question); ;
           //  return view('welcome');
         }
       
    }
    function surveyone(Request $request){
   // dd($request->all());
    $userans = new UserAns;
    $userans->survey_ans1 = $request->survey_one1;
    $userans->survey_ans2 = $request->survey_one2;
    $userans->survey_name   = $request->surveyname  ;
    $userans->question1   = $request->question1  ;
     $userans->question2   = $request->question2  ;
    $userans->user_id = $request->user_id;
    $userans->save();
         $question = Question::with('options')->where('page_name','=','survey_two')->get();
             return view('questionpagetwo')->with('question', $question); ;
    }
     function surveytwo(Request $request){

        $userans = new UserAns;
    $userans->survey_ans1 = $request->survey_one3;
    $userans->survey_ans2 = $request->survey_one4;
    $userans->survey_name   = $request->surveyname  ;
    $userans->question1   = $request->question3  ;
     $userans->question2   = $request->question4  ; 
    $userans->user_id = $request->user_id;
    $userans->save();

   $user = Auth::user();
    User::where('id', $user->id)
                ->update(['page_ans' => 1]);
    
    $userans->save();
    $question = UserAns::where('user_id','=', $user->id)->get();
             return view('surveythanks')->with('question', $question); ;
           
    }
}
