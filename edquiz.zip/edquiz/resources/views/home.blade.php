@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif

                     <h1>Your Survey Ans</h1>
                        @foreach ($question as $questions)
                          <h2>  <?php echo $questions['question1']; ?></h2>
                             <p> <?php echo $questions['survey_ans1']; ?></p>
                          <h2>  <?php echo $questions['question2']; ?></h2>
                             <p> <?php echo $questions['survey_ans2']; ?></p>
                        @endforeach 
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
