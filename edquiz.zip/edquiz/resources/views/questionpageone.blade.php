<?php
//echo '<pre>';
//dd($question);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Survey One</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="card container well well-sm" >
  <h2 class="card-header">Survey One</h2>

  

  
  <form action="{{action('HomeController@surveyone')}}" method='post'>
    @foreach ($question as $questions)
      <h2>  <?php echo $questions['description']; ?></h2>
        @foreach ($questions->options as $option)
         
            <label for="email"><?php echo $option['text'] ?>:</label>
            <input type="radio"  id="email" required value="<?php echo $option['text'] ?>"  name="survey_one<?php echo $option['quiz_question_id'] ?>">
        
        @endforeach 
   
    <input type="hidden" name="question<?php echo $option['quiz_question_id'] ?>" value=" <?php echo $questions['description']; ?>">
    @endforeach 
    <div>
      <input type="hidden" name="surveyname" value="survey_one">
      <input type="hidden" name="user_id" value="{{ Auth::user()->id }}">
      {{ csrf_field() }}
     <button type="submit" class="btn btn-default">Next</button>
     </div>
  </form>
</div>

</body>
</html>

