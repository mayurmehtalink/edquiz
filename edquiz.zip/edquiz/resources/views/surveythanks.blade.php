<!DOCTYPE html>
<html lang="en">
<head>
  <title>Survey One</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="jumbotron text-center">
  <h1 class="display-3">Thank You! </h1>
 
  <p class="lead">
    <a class="btn btn-primary btn-sm" href="{{action('HomeController@index')}}" role="button">Home</a>
  </p>
  <h1>Your Survey Ans</h1>
    @foreach ($question as $questions)
      <h2>  <?php echo $questions['question1']; ?></h2>
         <p> <?php echo $questions['survey_ans1']; ?></p>
      <h2>  <?php echo $questions['question2']; ?></h2>
         <p> <?php echo $questions['survey_ans2']; ?></p>
    @endforeach 
</div>
<script> setTimeout(function(){window.location='/home'}, 3000); </script>