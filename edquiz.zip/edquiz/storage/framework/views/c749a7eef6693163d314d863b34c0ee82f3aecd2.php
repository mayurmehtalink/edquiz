<?php
//echo '<pre>';
//dd($question);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Survey One</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="card container well well-sm" >
  <h2 class="card-header">Survey One</h2>

  

  
  <form action="<?php echo e(action('HomeController@surveyone')); ?>" method='post'>
    <?php $__currentLoopData = $question; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $questions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <h2>  <?php echo $questions['description']; ?></h2>
        <?php $__currentLoopData = $questions->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         
            <label for="email"><?php echo $option['text'] ?>:</label>
            <input type="radio"  id="email" required value="<?php echo $option['text'] ?>"  name="survey_one<?php echo $option['quiz_question_id'] ?>">
        
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
   
    <input type="hidden" name="question<?php echo $option['quiz_question_id'] ?>" value=" <?php echo $questions['description']; ?>">
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
    <div>
      <input type="hidden" name="surveyname" value="survey_one">
      <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
      <?php echo e(csrf_field()); ?>

     <button type="submit" class="btn btn-default">Next</button>
     </div>
  </form>
</div>

</body>
</html>

<?php /**PATH C:\xampp\htdocs\edquiz\resources\views/questionpageone.blade.php ENDPATH**/ ?>