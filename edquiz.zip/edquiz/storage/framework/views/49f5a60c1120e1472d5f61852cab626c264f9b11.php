<!DOCTYPE html>
<html lang="en">
<head>
  <title>Survey One</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="jumbotron text-center">
  <h1 class="display-3">Thank You! </h1>
 
  <p class="lead">
    <a class="btn btn-primary btn-sm" href="<?php echo e(action('HomeController@index')); ?>" role="button">Home</a>
  </p>
  <h1>Your Survey Ans</h1>
    <?php $__currentLoopData = $question; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $questions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <h2>  <?php echo $questions['question1']; ?></h2>
         <p> <?php echo $questions['survey_ans1']; ?></p>
      <h2>  <?php echo $questions['question2']; ?></h2>
         <p> <?php echo $questions['survey_ans2']; ?></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
</div>
<script> setTimeout(function(){window.location='/home'}, 2000); </script><?php /**PATH C:\xampp\htdocs\edquiz\resources\views/surveythanks.blade.php ENDPATH**/ ?>